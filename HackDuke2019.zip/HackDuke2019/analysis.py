from textblob import TextBlob
import requests
from bs4 import BeautifulSoup
from sys import argv

class Analysis:
    def __init__(self, term):
        self.term = term

        self.url = 'https://www.google.com/search?q={0}&source=lnms&tbm=nws'.format(self.term)

    def run (self):
        response = requests.get(self.url)
        soup = BeautifulSoup(response.text, 'html.parser')
        search_results = soup.select('.r a')
        headline_results = soup.find_all('div', class_='st')

        headlines = []
        for h in headline_results[1:4]:
            blob = TextBlob(h.get_text())
            headlines.append(str(blob))

        links = []
        for link in search_results[1:4]:
            links.append('https://google.com/' + link.get('href'))

        data = []
        for i in range(len(links)):
            data.append((headlines[i], links[i]))

        return data
#a = Analysis(argv[1])
#a.run()