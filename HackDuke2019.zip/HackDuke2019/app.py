import flask
from sklearn.externals import joblib
from newspaper import Article
import os
from analysis import Analysis

os.chdir("C:/Users/thken/Desktop/hackathons/HackDuke/HackDuke2019-master/HackDuke2019-master/HackDuke2019")

model = joblib.load("model/new_content.pkl")

app = flask.Flask(__name__, template_folder='templates')
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

@app.route('/')
def main():
    return(flask.render_template('main.html'))

@app.route('/', methods=['POST'])
def predict():
    url = flask.request.form['name']
    article = Article(url)
    article.download()
    article.parse()
    text = str(article.text)
    prediction = model.predict([text])[0]
    data = []
    title = ''
    if prediction == 'unreliable':
        a = Analysis(article.title)
        data = a.run()
        title = 'Here Are Some Reliable Sources About this Topic'

    return flask.render_template('main.html', result=prediction.upper(), searches=data, Title=title)

@app.route('/')
def gen_search(data):
    print(data)
    return flask.render_template('main.html', searches=data)

if __name__ == '__main__':
    app.run(debug=False)
    
@app.after_request
def add_header(response):
    # response.cache_control.no_store = True
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response